module I18n
  module ActiveRecord
    VERSION = "0.0.2"
  end
end

